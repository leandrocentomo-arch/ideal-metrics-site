<?php

include_once STAL_CORE_INC_PATH . '/header/layouts/divided/helper.php';
include_once STAL_CORE_INC_PATH . '/header/layouts/divided/divided-header.php';
include_once STAL_CORE_INC_PATH . '/header/layouts/divided/dashboard/admin/divided-header-options.php';
include_once STAL_CORE_INC_PATH . '/header/layouts/divided/dashboard/meta/divided-header-meta.php';