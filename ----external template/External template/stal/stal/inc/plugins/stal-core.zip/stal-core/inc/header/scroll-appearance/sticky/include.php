<?php

include_once STAL_CORE_INC_PATH . '/header/scroll-appearance/sticky/helper.php';
include_once STAL_CORE_INC_PATH . '/header/scroll-appearance/sticky/dashboard/admin/sticky-header-options.php';
include_once STAL_CORE_INC_PATH . '/header/scroll-appearance/sticky/dashboard/meta/sticky-header-meta.php';